
const {Pool} = require('pg')

exports.pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'email_account',
    password: 'aviral@1234',
    port: 5432,
})

 // user:'hello.01aviral@gmail.com'
// pass: 'limb uxnt zazk hlju'
