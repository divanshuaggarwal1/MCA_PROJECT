//List of error codes defined 
exports.SUCCESS = 200;
exports.UNEXPECTED = 1;
exports.NOT_FOUND = 404;
exports.NOT_AUTH = 2;
